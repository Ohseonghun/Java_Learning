package com.ev.p.data;

public class Sale {

}
