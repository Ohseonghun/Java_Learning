package com.ev.p.data;

public class Ev {
String name;
String price;
String color;
String speed;
public Ev(String name,String price,String color,String speed){
this.name=name;
this.price=price;
this.color=color;
this.speed=speed;

}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getPrice() {
	return price;
}
public void setPrice(String price) {
	this.price = price;
}
public String getColor() {
	return color;
}
public void setColor(String color) {
	this.color = color;
}
public String getSpeed() {
	return speed;
}
public void setSpeed(String speed) {
	this.speed = speed;
}
public void info() {
	System.out.println("ȸ���̸���"+name+"���ǰ�����"+price+"���Ǽӵ���"+speed+"���ǻ�����"+color+"�Դϴ�");
}
}
