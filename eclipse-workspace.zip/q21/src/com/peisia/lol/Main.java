package com.peisia.lol;

import ccom.peisia.lol.control.Game;

public class Main {
	public static void main(String[] args) {
		Game game = new Game();
		game.start();
	}
}