package ccom.peisia.lol.control;

import com.peisia.lol.img.Entrance;

public class Game {
	String cmd = "";
	public void start() {
		Entrance.show();
		
		String cmd = Command.getCommand("asdsa");
		
		System.out.println(cmd);
	}
}