package q34;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	Member2 mem2 = new Member2();
	  mem2.setName("õ��");
	  mem2.setSex("����");
	  mem2.setTel(7777);

  mem2.info();
  Member mem = new Member();
  mem.setName("�Ǹ�");
  mem.setSex("����");
  mem.setTel(6666);
  mem.info();
	}
}