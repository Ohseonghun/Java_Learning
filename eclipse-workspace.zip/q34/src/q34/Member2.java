package q34;

public class Member2 {
private String name;
private String sex;
private int tel;

public void setName(String name) {
	this.name = name;
	
}
public String getName() {
	return name;
}
public void setSex(String sex) {
	this.sex = sex;
}
public String getSex() {
	return sex;
}
public void setTel(int tel) {
	this.tel= tel;
}
public int getTel() {
	return tel;
}
void info() {
	System.out.println(name+sex+tel);
}



}
















//public void setName(String name) {
//	this.name=name;
//}
//public String getName() {
//	return name;
//}
//public void setSex(String sex) {
//	this.sex=sex;
//}
//public String getSex() {
//	return sex;
//}
//public void setTel(int tel) {
//	this.tel=tel;
//}
//public int getTel() {
//	return tel;
//}
//void info() {
//	System.out.println(name+sex+tel);
//}

