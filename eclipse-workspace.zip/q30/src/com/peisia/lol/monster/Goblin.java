package com.peisia.lol.monster;



import com.peisia.lol.util.So;

public class Goblin {
	String name;
	int currentHp;
	int maxHp;
	int atk;

	public Goblin(String name, int currentHp, int maxHp, int atk) {
		this.name = name;
		this.currentHp = currentHp;
		this.maxHp = maxHp;
		this.atk = atk;
	}



	public void info() {
		So.p("[<"+name+">("+currentHp+"/"+maxHp+")]");
	}
}