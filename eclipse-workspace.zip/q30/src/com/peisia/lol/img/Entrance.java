package com.peisia.lol.img;

import com.peisia.lol.util.So;

public class Entrance {
	static final String ENTRANCE = 
			"****************************************************************\n" 
			+ " RPG v0.1.0 \n" 
			+ "****************************************************************\n";
	static public void show() {
		So.pl(ENTRANCE);
	}
}