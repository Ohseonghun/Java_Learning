package com.peisia.lol.util;

public class So {
static public void pl(String s) {
System.out.println(s);	
}
static public void p(String s) {
	System.out.println(s);
}

}
