package com.google.q36.data;

public class Member {
	private String name;
	private int tel;
	private String sex;
	public Member(String name, int tel, String sex) {
		this.name = name;
		this.tel = tel;
		this.sex = sex;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getTel() {
		return tel;
	}
	public void setTel(int tel) {
		this.tel = tel;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
	this.sex = sex;
	}
	public void info() {
		System.out.println("�̸�:"+name + " ��ȭ��ȣ:"+tel +" ����:"+ sex);
	}
	
}

