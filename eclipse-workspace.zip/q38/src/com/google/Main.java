package com.google;


import java.util.ArrayList;

import com.google.q36.data.Member;
import com.google.q36.display.Title;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println(Title.TITLE);
ArrayList<Member> members = new ArrayList<Member>();
members.add(new Member("�蹫��",010-4444-5454,"����"));
members.add(new Member("�����",010-6645-3232,"����"));
members.add(new Member("�蹫��",010-7486-5154,"����"));

for(Member m:members) {
	m.info();
}
	}
	
}
