package q015;

public class Dog {

}