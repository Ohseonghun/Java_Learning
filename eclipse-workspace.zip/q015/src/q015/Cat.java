package q015;

public class Cat {
	private static Cat cat = new Cat();

	private Cat() {
	}

	static Cat getInstance() {
		return cat;
	}
}
