package q015;

public class main {

	public static void main(String[] args) {
		Cat cat1 = Cat.getInstance();
		Cat cat2 = Cat.getInstance();
		
		System.out.println(System.identityHashCode(cat1));
		System.out.println(System.identityHashCode(cat2));
		
		Dog dog1 = new Dog();
		Dog dog2 = new Dog();
		
		System.out.println(System.identityHashCode(dog1));
		System.out.println(System.identityHashCode(dog2));
		System.out.println(dog1.hashCode());
		System.out.println(dog2.hashCode());
	}
}