package q33;

public class Member2 {
String name;
String sex;
int tel;
Member2(String name,String sex,int tel){
	this.name=name;
	this.sex=sex;
	this.tel=tel;
	
	
}
void info() {
	System.out.println(name+sex+tel);
}
}
