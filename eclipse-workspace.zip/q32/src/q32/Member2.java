package q32;

public class Member2 {

String name ;
String sex;
int tel;
void info() {
	System.out.println(name+tel+sex);
}
}
