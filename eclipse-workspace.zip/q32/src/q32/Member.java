package q32;
//��Ʈ��n
public class Member {
String name;
String sex;
int tel;
void info() {
	System.out.println(name+sex+tel);
}

}
