package com.peisia;

public class Games {
void info() {
	System.out.println("peisia");
}
}
