package com.Main;

import com.google.Game;
import com.peisia.Games;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Game riot = new Game();
Games nexns = new Games();

	}

}
