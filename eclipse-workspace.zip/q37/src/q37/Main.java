package q37;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

ArrayList<String> araay = new ArrayList<String>();
araay.add("��");
araay.add("������");
araay.add("�ʱ���");
for(int i=0;i<araay.size();i++) {
	System.out.println(araay.get(i));
}
for(String s:araay) {
	System.out.println(s);
}
araay.remove(0);
System.out.println("��������");
	for (int i=0;i<araay.size();i++) {
		System.out.println(araay.get(i));
	}
	for(String s:araay) {
		System.out.println(s);
		}
	araay.remove(0);
	System.out.println("������");
	
	boolean dog = araay.contains("�ʱ���");
	System.out.println("�ʱ������ճ�?"+dog);
	 
	}
	
	
}


