package ccom.peisia.lol.control;

import com.peisia.lol.data.string.Str;
import com.peisia.lol.data.user.User;
import com.peisia.lol.img.Entrance;
import com.peisia.lol.monster.Goblin;
import com.peisia.lol.monster.Orc;

public class Game {
	String cmd = "";
	public void start() {
		Entrance.show();
		User.characterName = Command.getCommand(Str.CMD_GUIDE_CHARACTER_NAME_INPUT);
		User.characterSex= Command.getCommand(Str.CMD_GUIDE_CHARACTER_SEX_INPUT);
		User.characterJob=Command.getCommand(Str.CMD_GUIDE_CHARACTER_JOB_INPUT);
		
		String s = String.format("����� �̸��� %s �Դϴ�~", User.characterName);
      s+= String.format("����� ������ %s �Դϴ�~\n",User.characterSex);
      s+= String.format("����� ������ %s �Դϴ�~\n",User.characterJob );
		System.out.println(s);
	
		Orc orc1 = new Orc("��ũ����",100,100,10);
		Orc orc2 = new Orc("��ũ����",100,100,10);
		Goblin goblin1 = new Goblin("������",70,50,20);
		Goblin goblin2 = new Goblin("������",70,50,20);
		Goblin goblin3 = new Goblin("������",70,50,20);
		orc1.info();
		orc2.info();
		goblin1.info();
		goblin2.info();
		goblin2.info();
		System.out.println("");
		gameRun();
		
		}
	private void gameRun() {
		User.info();
		boolean isNotEnd = true;
		while(isNotEnd) {
			String cmd = Command.getCommand("");
			switch(cmd) {
			case "exit":
				isNotEnd = false;
				break;
			}
		}
		gameOver();
		
	}
	private void gameOver() {
		System.out.println(Str.MSG_GAME_OVER);
		
		
			}
			
		}
	
