package com.ev.p.pull;

public class Sale {

}
