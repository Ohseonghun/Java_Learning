package com.ev.p.kind;

public class Sale {

}
