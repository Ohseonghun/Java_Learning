package com.ev.p.util;

public class Part {
	
private String name;
private String handle;
private String leather;
private String tire;
private String window;
public  Part(String name,String handle,String leather,String tire,String window){
	this.name=name;
	this.handle=handle;
	this.leather=leather;
	this.tire= tire;
	this.window= window;
	
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getHandle() {
	return handle;
}
public void setHandle(String handle) {
	this.handle = handle;
}
public String getLeather() {
	return leather;
}
public void setLeather(String leather) {
	this.leather = leather;
}
public String getTire() {
	return tire;
}
public void setTire(String tire) {
	this.tire = tire;
}
public String getWindow() {
	return window;
}
public void setWindow(String window) {
	this.window = window;
}
public void info() {
	System.out.println("�������̸���"+name+"�ڵ鿡ǰ����"+handle+"Ÿ�̾���Դ�"+tire+"â����������"+window+"���׿������"+leather+"�Դϴ�");
}
}
