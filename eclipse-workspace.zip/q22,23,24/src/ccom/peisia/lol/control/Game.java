package ccom.peisia.lol.control;

import com.peisia.lol.img.Entrance;

public class Game {
	String cmd = "";

	public void start() {
		Entrance.show();

		String cmd = Command.getCommand("��������");

		System.out.println(cmd);
	}
}