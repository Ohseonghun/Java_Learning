package com.peisia.lol.monster;

public class Orc {

}
