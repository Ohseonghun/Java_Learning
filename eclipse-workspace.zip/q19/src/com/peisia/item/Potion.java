package com.peisia.item;

public class Potion {

}
