package com.peisia.item;

public class Weapon {

}
