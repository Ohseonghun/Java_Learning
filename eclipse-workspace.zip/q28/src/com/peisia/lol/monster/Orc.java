package com.peisia.lol.monster;

public class Orc {
	String name;
	int currentHp;
	int maxHp;
	int atk;

   public Orc(String name,int currentHp,int maxHp,int atk) {
	   super();
	   this.name = name;
	   this.currentHp = currentHp;
	   this.maxHp=maxHp;
	   this.atk= atk;
	   
   }
public void info() {
	System.out.println("[<"+name+">("+currentHp+"/"+maxHp+")]");
}
}