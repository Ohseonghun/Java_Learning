package ccom.peisia.lol.control;

import com.peisia.lol.data.string.Str;
import com.peisia.lol.data.user.User;
import com.peisia.lol.img.Entrance;

public class Game {
	String cmd = "";
	public void start() {
		Entrance.show();
		
		String cmd = Command.getCommand(Str.CMD_GUIDE_CHARACTER_NAME_INPUT);
		String s = String.format("����� �̸��� %s �Դϴ�~", User.characterName);
      
		System.out.println(s);
	}
}