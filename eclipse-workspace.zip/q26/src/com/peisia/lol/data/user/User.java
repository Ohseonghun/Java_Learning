package com.peisia.lol.data.user;

public class User {

	static public String characterName = "";
}
