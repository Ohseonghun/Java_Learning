package q34;

public class Member2 {





}
