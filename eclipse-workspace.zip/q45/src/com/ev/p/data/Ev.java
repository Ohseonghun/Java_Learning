package com.ev.p.data;

public class Ev {
private Integer num;
private String name; 
private String price;
private String color;
private String speed;
private float kg;
public Ev(Integer num,String name,String price,String color,String speed){
this.num= num;
this.name=name;
this.price=price;
this.color=color;
this.speed=speed;

}
public Ev(Integer num,String name,String price,String color,String speed,float kg){
this.num= num;
this.name=name;
this.price=price;
this.color=color;
this.speed=speed;
this.kg=kg;

}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getPrice() {
	return price;
}
public void setPrice(String price) {
	this.price = price;
}
public String getColor() {
	return color;
}
public void setColor(String color) {
	this.color = color;
}
public Integer getNum() {
	return num;
}
public void setNum(Integer num) {
	this.num = num;
}
public String getSpeed() {
	return speed;
}
public void setSpeed(String speed) {
	this.speed = speed;
}
public void info() {
	System.out.println("ȸ����ȣ"+num+"ȸ���̸���"+name+"���ǰ�����"+price+"���Ǽӵ���"+speed+"���ǻ�����"+color+"�Դϴ�");
}
}
